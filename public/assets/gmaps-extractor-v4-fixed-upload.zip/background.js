// GMaps Lead Extractor Pro v4.0 — background.js
// FIXES v4.0:
// 1. [CRITICAL] Service worker keepalive — prevents SW death on large batches (100+ leads)
// 2. [CRITICAL] Dedup key improved — name+mapsUrl (not name+address) prevents
//              duplicates when deepExtract saves over the basicExtract results
// 3. [CRITICAL] Lat/Lng from mapsUrl arg fallback — fixes 0% lat/lng coverage
// 4. Reviews Method 4 — jsaction[*="rating"] selector for new Maps HTML
// 5. extractFullDetails now receives mapsUrl as argument for lat/lng fallback
// 6. waitForMapsContent timeout increased 10s→15s for slow connections
'use strict';

const LEADS_KEY = 'gmaps_v4_leads';

chrome.runtime.onInstalled.addListener(() => getLeads().then(l => setBadge(l.length)));
chrome.storage.onChanged.addListener(c => { if (c[LEADS_KEY]) setBadge((c[LEADS_KEY].newValue||[]).length); });
getLeads().then(l => setBadge(l.length));

function getLeads() { return new Promise(res => chrome.storage.local.get(LEADS_KEY, d => res(d[LEADS_KEY]??[]))); }
function setLeads(l) { return chrome.storage.local.set({[LEADS_KEY]:l}); }
function setBadge(n) { chrome.action.setBadgeText({text:n>0?String(n):''}); chrome.action.setBadgeBackgroundColor({color:'#00c853'}); }
function wait(ms) { return new Promise(r=>setTimeout(r,ms)); }

/* ══════════════════════════════════════════════════════
   KEEPALIVE — prevents MV3 service worker from sleeping
   mid-batch on large lead sets (100+ leads × ~3s each)
══════════════════════════════════════════════════════ */
let _kaTimer = null;
function startKeepalive() {
  function ping() {
    chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError);
    _kaTimer = setTimeout(ping, 20000);
  }
  ping();
}
function stopKeepalive() {
  if (_kaTimer) { clearTimeout(_kaTimer); _kaTimer = null; }
}

/* ══════════════════════════════════════════════════════
   FULL DETAIL EXTRACTOR
   Injected into each business tab via executeScript.
   Receives mapsUrl for lat/lng fallback.
══════════════════════════════════════════════════════ */
function extractFullDetails(mapsUrl) {
  // ── Helpers ──
  const q   = (s,r) => { try{return (r||document).querySelector(s);}catch{return null;} };
  const qq  = (s,r) => { try{return [...(r||document).querySelectorAll(s)];}catch{return [];} };
  const txt = el   => el ? el.textContent.replace(/\s+/g,' ').trim() : '';
  const atr = (el,a)=> el ? (el.getAttribute(a)||'').trim() : '';

  const R = {};

  // ── Name ──
  R.name = txt(q('h1.DUwDvf')||q('h1[class*="DUwDvf"]')||q('[role="main"] h1')||q('h1'));

  // ── Rating ──
  const rEl = q('[aria-label*="stars"],[aria-label*=" star"],[role="img"][aria-label*="star"]');
  R.rating  = rEl ? ((atr(rEl,'aria-label')).match(/[\d.]+/)||[])[0]||'' : '';

  // ── Reviews ──
  // Method 1: aria-label with "reviews"
  const rvEl = q('[aria-label*="reviews"],[aria-label*="review"]');
  if (rvEl) R.reviews = ((atr(rvEl,'aria-label')||txt(rvEl)).match(/[\d,]+/)||[])[0]?.replace(/,/g,'')||'';
  // Method 2: button/span with "N reviews" text
  if (!R.reviews) {
    qq('button,span').forEach(el => {
      if (R.reviews) return;
      const t = txt(el);
      const m = t.match(/^([\d,]+)\s+reviews?$/i);
      if (m) R.reviews = m[1].replace(/,/g,'');
    });
  }
  // Method 3: "(1,463)" pattern
  if (!R.reviews) {
    qq('span').forEach(el => {
      if (R.reviews) return;
      const t = txt(el);
      const m = t.match(/^\(([\d,]+)\)$/);
      if (m) R.reviews = m[1].replace(/,/g,'');
    });
  }
  // Method 4: new Maps HTML — jsaction containing "rating"
  if (!R.reviews) {
    qq('[jsaction*="rating"]').forEach(el => {
      if (R.reviews) return;
      const t = txt(el);
      const m = t.match(/\(([\d,]+)\)/);
      if (m) R.reviews = m[1].replace(/,/g,'');
    });
  }

  // ── Category ──
  const catEl = q('button.DkEaL')||q('[class*="DkEaL"]');
  const cat   = catEl ? txt(catEl) : '';
  R.category  = (cat && cat.toLowerCase() !== (R.name||'').toLowerCase()) ? cat : '';

  // ── Phone (5 methods) ──
  let phone = '';
  for (const el of qq('[data-item-id]')) {
    if (phone) break;
    if ((el.dataset.itemId||'').toLowerCase().includes('phone')) {
      const t = txt(q('.Io6YTe,.fontBodyMedium,span[jsan]',el)||el);
      if (t && t.length > 5) phone = t;
    }
  }
  if (!phone) for (const el of qq('[aria-label]')) { if(phone)break; const a=atr(el,'aria-label'); if(/^Phone:/i.test(a)) phone=a.replace(/^Phone:\s*/i,'').trim(); }
  if (!phone) { const tel=q('a[href^="tel:"]'); if(tel) phone=decodeURIComponent(tel.href.replace('tel:','')).trim(); }
  if (!phone) { const btn=q('button[data-tooltip*="phone" i],button[aria-label*="phone" i]'); if(btn){const t=txt(q('.Io6YTe,.fontBodyMedium',btn));if(t)phone=t;} }
  if (!phone) {
    const re=/^(\+91[\s\-]?)?[6-9]\d{9}$|^\+\d{1,3}[\s\-]?\d{6,14}$|^0\d{2,4}[\s\-]?\d{6,8}$/;
    for (const el of qq('span,div,button,a')) {
      if (phone) break;
      if (el.children.length>0) continue;
      const raw=txt(el).replace(/[\s\-\(\)\.]/g,'');
      if(re.test(raw)) phone=txt(el);
    }
  }
  R.phone = phone.trim();

  // ── Full Address ──
  let addr = '';
  for (const el of qq('[data-item-id]')) {
    if (addr) break;
    if (el.dataset.itemId==='address') addr=txt(q('.Io6YTe,.fontBodyMedium',el)||el);
  }
  if (!addr) for (const el of qq('[aria-label]')) { if(addr)break; const a=atr(el,'aria-label'); if(/^Address:/i.test(a)) addr=a.replace(/^Address:\s*/i,'').trim(); }
  if (!addr) { const btn=q('button[data-tooltip*="address" i]'); if(btn) addr=txt(q('.Io6YTe,.fontBodyMedium',btn)||btn); }
  R.address = addr;

  // ── Parse Address Parts ──
  const parseAddr = (a) => {
    const p = { street:'', neighborhood:'', city:'', postalCode:'', state:'', country:'' };
    if (!a) return p;

    const pin = a.match(/\b(\d{6})\b/);
    if (pin) p.postalCode = pin[1];

    const segs = a.split(',').map(s=>s.trim()).filter(Boolean);

    const countriesRe = /^(India|IN|USA|US|UK|United States|United Kingdom|Australia|Canada|Singapore|Germany|France)$/i;
    if (segs.length && countriesRe.test(segs[segs.length-1])) {
      p.country = segs.pop();
    } else if (segs.length && /India/i.test(segs[segs.length-1])) {
      p.country = 'India';
      segs[segs.length-1] = segs[segs.length-1].replace(/,?\s*India/i,'').trim();
      if (!segs[segs.length-1]) segs.pop();
    }

    if (segs.length) {
      const last = segs[segs.length-1];
      const stMatch = last.match(/^([A-Za-z\s]+)\s+\d{6}$/);
      if (stMatch) { p.state = stMatch[1].trim(); segs.pop(); }
      else if (/^[A-Za-z][A-Za-z\s]{2,}$/.test(last)) { p.state = last; segs.pop(); }
    }

    if (segs.length) { p.city = segs.pop(); }
    if (segs.length) { p.neighborhood = segs.pop(); }
    if (segs.length) { p.street = segs.join(', '); }

    return p;
  };

  const ap = parseAddr(addr);
  R.street       = ap.street;
  R.neighborhood = ap.neighborhood;
  R.city         = ap.city;
  R.postalCode   = ap.postalCode;
  R.state        = ap.state;
  R.country      = ap.country || 'India';

  // ── Website ──
  let website = '';
  const wEl = q('a[data-item-id="authority"]')||q('a[aria-label*="website" i]');
  if (wEl) { let h=wEl.href||''; if(h.includes('google.com/url')){try{h=new URL(h).searchParams.get('q')||h;}catch{}} website=h; }
  R.website = website;

  // ── Permanently / Temporarily Closed ──
  const pageText = document.body.innerText || '';
  R.permanentlyClosed = /permanently\s+closed/i.test(pageText);
  R.temporarilyClosed = /temporarily\s+closed/i.test(pageText);

  // ── Opening Hours ──
  const hours = [];

  qq('table tr, [jsaction*="openhours"] tr').forEach(row => {
    const cells = qq('td,th', row);
    if (cells.length >= 2) {
      const day  = txt(cells[0]);
      const time = txt(cells[1]);
      if (day && time && /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)/i.test(day)) {
        hours.push(`${day}: ${time}`);
      }
    }
  });

  if (!hours.length) {
    qq('[aria-label]').forEach(el => {
      const a = atr(el,'aria-label');
      if (/\d+\s*(AM|PM|am|pm)/.test(a) && /(Mon|Tue|Wed|Thu|Fri|Sat|Sun)/i.test(a)) {
        const parts = a.split(/;\s*|,\s*(?=[A-Z])/);
        parts.forEach(p => {
          const m = p.match(/((?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*)[,:]?\s+(.+)/i);
          if (m && !hours.find(h=>h.startsWith(m[1]))) hours.push(`${m[1]}: ${m[2].trim()}`);
        });
      }
    });
  }

  if (!hours.length) {
    const dayRe = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)$/i;
    const timeRe = /\d+\s*(AM|PM|am|pm)/;
    let pendingDay = '';
    for (const el of qq('span,div,td,li,tr')) {
      const t = txt(el);
      if (dayRe.test(t)) { pendingDay = t; }
      else if (pendingDay && timeRe.test(t) && t.length < 60) {
        hours.push(`${pendingDay}: ${t}`);
        pendingDay = '';
      }
    }
  }

  R.openingHours = [...new Set(hours)].join(' | ');

  // ── Lat / Lng ──
  // FIX v4.0: 4-method cascade — last resort uses mapsUrl arg passed from lead list
  let lat = '', lng = '';

  // Method 1: current tab URL
  const co1 = location.href.match(/@([-\d.]+),([-\d.]+)/);
  if (co1) { lat = co1[1]; lng = co1[2]; }

  // Method 2: canonical <link> tag
  if (!lat) {
    const canon = q('link[rel="canonical"]');
    const co2 = (canon?.href||'').match(/@([-\d.]+),([-\d.]+)/);
    if (co2) { lat = co2[1]; lng = co2[2]; }
  }

  // Method 3: any <a href> containing @lat,lng on the page
  if (!lat) {
    for (const l of qq('a[href*="@"]')) {
      const co3 = (l.href||'').match(/@([-\d.]+),([-\d.]+)/);
      if (co3) { lat = co3[1]; lng = co3[2]; break; }
    }
  }

  // Method 4: fallback to mapsUrl from list scrape (passed as arg) — fixes 0% lat/lng
  if (!lat && mapsUrl) {
    const co4 = mapsUrl.match(/@([-\d.]+),([-\d.]+)/);
    if (co4) { lat = co4[1]; lng = co4[2]; }
  }

  R.lat = lat;
  R.lng = lng;

  return R;
}

/* ── Poll until page is fully rendered ── */
function waitForMapsContent(tabId, timeoutMs) {
  return new Promise(resolve => {
    const deadline = Date.now() + timeoutMs;

    async function check() {
      if (Date.now() > deadline) { resolve(false); return; }

      try {
        const res = await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const h1    = document.querySelector('h1.DUwDvf,[class*="DUwDvf"],[role="main"] h1,h1');
            const items = document.querySelectorAll('[data-item-id]');
            const hasH1   = h1 && h1.textContent.trim().length > 1;
            const hasData = items.length > 0;
            return { ready: hasH1 && hasData, h1: h1?.textContent?.trim()?.slice(0,30)||'' };
          }
        });

        const { ready } = res?.[0]?.result || {};
        if (ready) { resolve(true); }
        else { setTimeout(check, 400); }
      } catch {
        setTimeout(check, 500);
      }
    }

    check();
  });
}

/* ── Main orchestrator ── */
async function extractPhonesViaBackgroundTabs(leads) {
  const results = [];

  // FIX v4.0: keepalive prevents SW death on large batches
  startKeepalive();

  try {
    for (let i = 0; i < leads.length; i++) {
      const lead   = leads[i];
      let   detail = {};
      let   tab    = null; // FIX: declared outside try so catch block can reference it

      try {
        tab = await chrome.tabs.create({ url: lead.mapsUrl, active: false });

        await waitForTabLoad(tab.id, 15000);

        // FIX v4.0: increased timeout 10s→15s for slow connections
        const ready = await waitForMapsContent(tab.id, 15000);

        if (!ready) {
          console.warn(`[BG v4.0] Content not ready for "${lead.name}" — extracting anyway`);
        }

        await wait(800);

        // FIX v4.0: pass mapsUrl as arg so extractFullDetails can use it for lat/lng fallback
        const exec = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: extractFullDetails,
          args: [lead.mapsUrl]
        });
        detail = exec?.[0]?.result || {};

        await chrome.tabs.remove(tab.id).catch(()=>{});

        console.log(`[BG v4.0] ✓ ${i+1}/${leads.length}: "${lead.name}" | phone="${detail.phone}" | lat="${detail.lat}"`);

      } catch(err) {
        console.error(`[BG v4.0] ✗ "${lead.name}":`, err.message);
        // FIX: tab is now in scope — reliably closes the background tab on error
        if (tab?.id != null) try { await chrome.tabs.remove(tab.id); } catch {}
      }

      results.push({
        ...lead,
        phone:             detail.phone             || lead.phone    || '',
        address:           detail.address           || lead.address  || '',
        street:            detail.street            || lead.street   || '',
        neighborhood:      detail.neighborhood      || lead.neighborhood || '',
        city:              detail.city              || lead.city     || '',
        postalCode:        detail.postalCode        || lead.postalCode || '',
        state:             detail.state             || lead.state    || '',
        country:           detail.country           || lead.country  || '',
        website:           detail.website           || lead.website  || '',
        category:          detail.category          || lead.category || '',
        rating:            detail.rating            || lead.rating   || '',
        reviews:           detail.reviews           || lead.reviews  || '',
        openingHours:      detail.openingHours      || lead.openingHours || '',
        permanentlyClosed: detail.permanentlyClosed ?? lead.permanentlyClosed ?? false,
        temporarilyClosed: detail.temporarilyClosed ?? lead.temporarilyClosed ?? false,
        lat:               detail.lat               || lead.lat      || '',
        lng:               detail.lng               || lead.lng      || '',
      });

      try {
        chrome.runtime.sendMessage({
          action:'progressUpdate', count:i+1, total:leads.length,
          phase:'deep', currentName:lead.name
        });
      } catch {}
    }
  } finally {
    // Always stop keepalive when done (success or error)
    stopKeepalive();
  }

  return results;
}

function waitForTabLoad(tabId, timeoutMs) {
  return new Promise(resolve => {
    // FIX: clean up both listeners on timeout to prevent listener leaks
    function cleanup() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
    }
    const timer = setTimeout(() => { cleanup(); resolve(); }, timeoutMs);
    function onUpdated(id, info) {
      if (id === tabId && info.status === 'complete') { cleanup(); resolve(); }
    }
    // FIX: also resolve if the tab is closed unexpectedly (prevents hanging)
    function onRemoved(id) {
      if (id === tabId) { cleanup(); resolve(); }
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

/* ── Messages ── */
chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  switch(msg.action) {
    case 'getLeads':
      getLeads().then(l=>sendResponse({leads:l})); return true;

    case 'saveLeads':
      getLeads().then(existing => {
        const map = new Map();

        // FIX v4.0: dedup key = name + mapsUrl (not name + address)
        // This ensures deepExtract results REPLACE the basic-extract stubs
        // instead of creating duplicate rows (the root cause of the 51-duplicate bug)
        const makeKey = l => {
          const nameKey = (l.name||'').toLowerCase().replace(/\s/g,'');
          // Normalize mapsUrl — strip query params, keep just the place path
          let urlKey = '';
          try {
            const u = new URL(l.mapsUrl||'');
            // Extract just the /maps/place/Name/@lat,lng part (drop extra params)
            urlKey = u.pathname.replace(/\/$/, '');
          } catch {
            urlKey = (l.mapsUrl||'').split('?')[0];
          }
          return nameKey + '|' + urlKey;
        };

        // Load existing first
        existing.forEach(l => map.set(makeKey(l), l));

        // New leads OVERWRITE existing stubs (deep > basic)
        // A lead with more data wins over a stub
        (msg.leads||[]).forEach(l => {
          const key = makeKey(l);
          const existing_entry = map.get(key);
          if (!existing_entry) {
            map.set(key, l);
          } else {
            // Merge: prefer the entry with more populated fields
            const score = e => [e.phone, e.address, e.city, e.lat].filter(Boolean).length;
            map.set(key, score(l) >= score(existing_entry) ? l : existing_entry);
          }
        });

        const merged = [...map.values()];
        setLeads(merged).then(() => { setBadge(merged.length); sendResponse({total:merged.length}); });
      }); return true;

    case 'clearLeads':
      setLeads([]).then(()=>{setBadge(0);sendResponse({ok:true});}); return true;

    case 'deepExtractPhones':
      extractPhonesViaBackgroundTabs(msg.leads||[])
        .then(r=>sendResponse({results:r}))
        .catch(e=>sendResponse({results:[],error:e.message}));
      return true;

    case 'progress':
      chrome.action.setBadgeText({text:'~'+msg.count});
      chrome.action.setBadgeBackgroundColor({color:'#7c6cfc'});
      chrome.runtime.sendMessage({action:'progressUpdate',count:msg.count,phase:msg.phase||'scroll'},()=>{void chrome.runtime.lastError;});
      return false;
  }
});
