// GMaps Lead Extractor Pro v4.0 — content.js
// Content script: list extraction + auto-scroll only
// Phone/full-detail extraction done via background tabs (background.js)
(function () {
  'use strict';

  if (window.__gmapsV4Loaded) return;
  window.__gmapsV4Loaded = true;
  console.log('[GMaps v4.0] Content script ready');

  window.addEventListener('pageshow', e => {
    if (e.persisted) { window.__gmapsV4Loaded = false; }
  });

  /* ── UTILS ── */
  const q    = (s,r) => { try{return (r||document).querySelector(s);}catch{return null;} };
  const qq   = (s,r) => { try{return [...(r||document).querySelectorAll(s)];}catch{return [];} };
  const txt  = el   => el ? el.textContent.replace(/\s+/g,' ').trim() : '';
  const attr = (el,a)=> el ? (el.getAttribute(a)||'').trim() : '';
  const first= (ss,r)=> { for(const s of ss){const e=q(s,r);if(e)return e;} return null; };
  const ftxt = (ss,r)=> txt(first(ss,r));
  const wait = ms   => new Promise(r=>setTimeout(r,ms));

  /* ── FIND RESULTS FEED ── */
  function findFeed() {
    const sels = [
      '[role="feed"]',
      'div[aria-label*="Results for"]',
      'div[aria-label*="results for"]',
      '.m6QErb[aria-label]',
      '.m6QErb.DxyBCb',
      '.m6QErb'
    ];
    for (const s of sels) {
      const el = q(s);
      if (el && el.querySelectorAll('a[href*="/maps/place/"]').length > 0) return el;
    }
    return qq('div').find(d =>
      d.querySelectorAll('a[href*="/maps/place/"]').length >= 3 &&
      d.offsetHeight > 300 && d.scrollHeight > d.clientHeight
    ) || null;
  }

  function walkUpCard(el) {
    let node = el;
    for (let i = 0; i < 12; i++) {
      const p = node.parentElement;
      if (!p) break;
      if (p.offsetHeight > 60 && p.offsetWidth > 150) return p;
      node = p;
    }
    return el;
  }

  /* ── EXTRACT SINGLE CARD ── */
  function extractCard(link) {
    const card    = walkUpCard(link);
    const nameEl  = first(['[class*="fontHeadlineSmall"]','[class*="qBF1Pd"]','.NrDZNb','[class*="ZkP5Je"]','[role="heading"]'], card);
    const name    = txt(nameEl) || txt(link).split('\n')[0].trim();
    if (!name || name.length < 2) return null;

    const rEl    = q('[aria-label*="stars"],[aria-label*=" star"],[role="img"][aria-label*="star"]', card);
    const rating = rEl ? ((attr(rEl,'aria-label')).match(/[\d.]+/)||[])[0]||'' : '';

    let reviews = '';
    const rvEl = q('[aria-label*="reviews"],[aria-label*="review"]', card);
    if (rvEl) reviews = ((attr(rvEl,'aria-label')||txt(rvEl)).match(/[\d,]+/)||[])[0]?.replace(/,/g,'')||'';

    let category = '';
    const catEl = first(['button.DkEaL','[class*="DkEaL"]'], card);
    if (catEl) { const t=txt(catEl); if(t && t.toLowerCase()!==name.toLowerCase() && t.length<80) category=t; }

    let address = '';
    for (const el of qq('[aria-label]', card)) {
      if (address) break;
      const a = attr(el,'aria-label');
      if (/^Address:/i.test(a)) address = a.replace(/^Address:\s*/i,'').trim();
    }
    if (!address) {
      for (const el of qq('[data-item-id]', card)) {
        if (address) break;
        if (el.dataset.itemId === 'address') address = txt(q('.Io6YTe,.fontBodyMedium',el)||el);
      }
    }

    let website = '';
    const wEl = q('a[data-item-id="authority"],a[aria-label*="ebsite"]', card);
    if (wEl) { let h=wEl.href||''; if(h.includes('google.com/url')){try{h=new URL(h).searchParams.get('q')||h;}catch{}} website=h; }

    // Phone from tel: link (sometimes visible in list)
    let phone = '';
    const tel = q('a[href^="tel:"]', card);
    if (tel) phone = decodeURIComponent(tel.href.replace('tel:','')).trim();

    // Lat/Lng from the card's mapsUrl
    const co = (link.href||'').match(/@([-\d.]+),([-\d.]+)/);
    const lat = co ? co[1] : '';
    const lng = co ? co[2] : '';

    return {
      name, category, address, phone, website, rating, reviews,
      mapsUrl: link.href,
      lat, lng,
      date: new Date().toISOString().split('T')[0]
    };
  }

  /* ── EXTRACT FROM LIST ── */
  function extractFromList() {
    const feed  = findFeed();
    const root  = feed || document;
    const links = qq('a[href*="/maps/place/"]', root);
    console.log('[GMaps v4.0] Links:', links.length);

    if (!links.length) {
      const name = ftxt(['h1.DUwDvf','h1[class*="DUwDvf"]','.DUwDvf','[role="main"] h1','h1']);
      if (name) {
        const phone = (() => {
          const tel = q('a[href^="tel:"]');
          if (tel) return decodeURIComponent(tel.href.replace('tel:','')).trim();
          for (const el of qq('[data-item-id]')) {
            if ((el.dataset.itemId||'').toLowerCase().includes('phone')) {
              const t = txt(q('.Io6YTe,.fontBodyMedium',el)||el);
              if (t && t.length > 5) return t;
            }
          }
          return '';
        })();
        const co = location.href.match(/@([-\d.]+),([-\d.]+)/);
        return [{
          name, phone, category:'', address:'', website:'', rating:'', reviews:'',
          mapsUrl: location.href,
          lat: co?co[1]:'', lng: co?co[2]:'',
          date: new Date().toISOString().split('T')[0]
        }];
      }
      return [];
    }

    const out=[], seen=new Set();
    for (const link of links) {
      if (!link.href) continue;
      const lead = extractCard(link);
      if (!lead) continue;
      const key = lead.name.toLowerCase().replace(/\s+/g,'');
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(lead);
    }
    console.log('[GMaps v4.0] Extracted:', out.length, 'leads');
    return out;
  }

  /* ── AUTO SCROLL ── */
  async function autoScroll(max, feed) {
    let last=-1, stale=0; // FIX: initialize last to -1 so first scroll is never counted as stale
    for (let i=0; i<80; i++) {
      feed.scrollTop = feed.scrollHeight;
      try { feed.scrollTo({top:feed.scrollHeight,behavior:'smooth'}); } catch {}
      await wait(1400);
      const n = qq('a[href*="/maps/place/"]', feed).length;
      try { chrome.runtime.sendMessage({action:'progress',count:n,phase:'scroll'}); } catch {}
      console.log(`[GMaps v4.0] Scroll ${i+1}: ${n}`);
      if (n >= max) break;
      if (/you.ve reached the end|no more results/i.test(feed.innerText||'')) break;
      if (n===last) { if(++stale>=5) break; } else stale=0;
      last=n;
    }
  }

  /* ── EXTRACT CURRENT SINGLE PANEL ── */
  function extractCurrentPanel() {
    const name = ftxt(['h1.DUwDvf','h1[class*="DUwDvf"]','.DUwDvf','[role="main"] h1','h1']);
    if (!name) return null;
    const rEl    = first(['[aria-label*="stars"]','[aria-label*=" star"]','span[role="img"]']);
    const rating = rEl ? ((attr(rEl,'aria-label')).match(/[\d.]+/)||[])[0]||'' : '';
    const rvEl   = first(['[aria-label*="reviews"]','[aria-label*="review"]']);
    const reviews= rvEl ? ((attr(rvEl,'aria-label')||txt(rvEl)).match(/[\d,]+/)||[])[0]?.replace(/,/g,'')||'' : '';

    let phone='', address='', category='', website='';
    for (const el of qq('[data-item-id]')) {
      if ((el.dataset.itemId||'').toLowerCase().includes('phone') && !phone)
        phone = txt(q('.Io6YTe,.fontBodyMedium',el)||el);
      if (el.dataset.itemId==='address' && !address)
        address = txt(q('.Io6YTe,.fontBodyMedium',el)||el);
    }
    if (!phone) { const tel=q('a[href^="tel:"]'); if(tel) phone=decodeURIComponent(tel.href.replace('tel:','')).trim(); }
    category = ftxt(['button.DkEaL','[class*="DkEaL"]']);
    if (category.toLowerCase()===name.toLowerCase()) category='';
    const wEl=first(['a[data-item-id="authority"]','a[aria-label*="website" i]']);
    if(wEl){let h=wEl.href||'';if(h.includes('google.com/url')){try{h=new URL(h).searchParams.get('q')||h;}catch{}}website=h;}

    const co=location.href.match(/@([-\d.]+),([-\d.]+)/);
    return {
      name, category, address, phone, website, rating, reviews,
      mapsUrl: location.href.split('?')[0],
      lat: co?co[1]:'', lng: co?co[2]:'',
      date: new Date().toISOString().split('T')[0]
    };
  }

  /* ── MESSAGE LISTENER ── */
  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    console.log('[GMaps v4.0] Message:', req.action);
    if (req.action === 'ping')           { sendResponse({ok:true}); return true; }
    if (req.action === 'extractCurrent') { sendResponse({data:extractCurrentPanel()}); return true; }
    if (req.action === 'extractList')    { sendResponse({data:extractFromList()}); return true; }
    if (req.action === 'extractAll') {
      (async()=>{
        const feed=findFeed();
        if(feed) await autoScroll(req.max||200, feed);
        sendResponse({data:extractFromList()});
      })().catch(e=>sendResponse({data:[],error:e.message}));
      return true;
    }
    return true;
  });

})();
