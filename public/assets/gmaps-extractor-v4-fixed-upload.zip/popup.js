// GMaps Lead Extractor Pro v4.0 — popup.js
// FIXES v4.0:
// 1. deepExtract: use LEADS_KEY v4 (gmaps_v4_leads) consistent with background.js
// 2. deepExtract: does NOT save basic leads before deep extract — prevents duplicate stub creation
// 3. deepExtract timeout: scaled to lead count (8s per lead) instead of fixed Chrome default
// 4. Storage key updated to gmaps_v4_leads (old v3 data cleared automatically on first use)
'use strict';

const LEADS_KEY = 'gmaps_v4_leads'; // FIX: must match background.js

let allLeads     = [];
let sessionLeads = [];
let mapsTabId    = null;

const statusDot    = document.getElementById('statusDot');
const statusText   = document.getElementById('statusText');
const progressBox  = document.getElementById('progressBox');
const progressFill = document.getElementById('progressFill');
const progressCount= document.getElementById('progressCount');
const headerCount  = document.getElementById('headerCount');
const leadsCount   = document.getElementById('leadsCount');
const tableWrap    = document.getElementById('tableWrap');
const maxRange     = document.getElementById('maxRange');
const maxLabel     = document.getElementById('maxLabel');

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'leads') renderTable();
  });
});

maxRange.addEventListener('input', () => { maxLabel.textContent = maxRange.value; });

init();

async function init() {
  await loadLeads();
  await detectMapsTab();
}

async function loadLeads() {
  return new Promise(res => {
    chrome.runtime.sendMessage({ action: 'getLeads' }, r => {
      void chrome.runtime.lastError;
      allLeads = r?.leads || [];
      updateCounts();
      res();
    });
  });
}

async function detectMapsTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab  = tabs[0];
  const url  = tab?.url || '';
  if (!url.includes('google.com/maps') && !url.includes('maps.google.com')) {
    setStatus('red', '⚠️ Open Google Maps and search for businesses first');
    disableExtractBtns(); return;
  }
  mapsTabId = tab.id;
  await reinject(mapsTabId);
  const alive = await ping(mapsTabId);
  if (alive) { setStatus('green', '✅ Google Maps detected — Ready!'); enableExtractBtns(); }
  else       { setStatus('yellow', '⏳ Reload the Maps tab and reopen popup'); disableExtractBtns(); }
}

async function reinject(tabId) {
  try {
    await chrome.scripting.executeScript({ target:{tabId}, func:()=>{ delete window.__gmapsV4Loaded; } });
    await chrome.scripting.executeScript({ target:{tabId}, files:['content.js'] });
    await wait(350);
  } catch(e) { console.warn('[Popup v4] reinject:', e.message); }
}

function ping(tabId) {
  return new Promise(resolve => {
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, {action:'ping'}, r => {
        void chrome.runtime.lastError;
        resolve(r?.ok === true);
      });
    }, 200);
  });
}

function setStatus(color, msg) { statusDot.className='status-dot dot-'+color; statusText.textContent=msg; }
function disableExtractBtns() { ['btnCurrent','btnVisible','btnAll','btnDeep'].forEach(id=>document.getElementById(id).disabled=true); }
function enableExtractBtns()  { ['btnCurrent','btnVisible','btnAll','btnDeep'].forEach(id=>document.getElementById(id).disabled=false); }
function wait(ms) { return new Promise(r=>setTimeout(r,ms)); }

document.getElementById('btnCurrent').addEventListener('click', ()=>extractAction('extractCurrent'));
document.getElementById('btnVisible').addEventListener('click', ()=>extractAction('extractList'));
document.getElementById('btnAll').addEventListener('click',     ()=>extractAction('extractAll'));
document.getElementById('btnDeep').addEventListener('click',    ()=>deepExtractWithTabs());

async function extractAction(action) {
  if (!mapsTabId) { toast('Open Google Maps first!', true); return; }
  setStatus('yellow','⏳ Connecting…');
  progressBox.classList.add('show');
  progressFill.style.width='5%';
  progressCount.textContent='0 found';
  disableExtractBtns();
  try {
    await reinject(mapsTabId);
    if (!await ping(mapsTabId)) throw new Error('Could not reach Maps tab — reload it');
    setStatus('yellow','⏳ Extracting…');
    progressFill.style.width='15%';
    const r = await sendToTab(mapsTabId, { action, max: parseInt(maxRange.value)||60 });
    progressBox.classList.remove('show');
    enableExtractBtns();
    const raw = action==='extractCurrent' ? (r?.data?[r.data]:[]) : (r?.data||[]);
    if (!raw.length) { setStatus('yellow','⚠️ No businesses found.'); toast('Nothing extracted.',true); return; }
    sessionLeads = raw;
    await saveLeads(raw);
    await loadLeads();
    setStatus('green',`✅ ${raw.length} leads saved! Total: ${allLeads.length}`);
    toast(`✅ ${raw.length} leads saved!`);
    updateCounts();
  } catch(err) {
    progressBox.classList.remove('show');
    enableExtractBtns();
    setStatus('red','❌ '+err.message);
    toast(err.message, true);
  }
}

/* ══════════════════════════════════════════════
   DEEP EXTRACT — Background Tabs
   FIX v4.0: does NOT pre-save basic leads, preventing
   duplicate stubs that then can't be deduped correctly.
   Timeout scaled to lead count × 8s.
══════════════════════════════════════════════ */
async function deepExtractWithTabs() {
  if (!mapsTabId) { toast('Open Google Maps first!', true); return; }
  setStatus('yellow','⏳ Loading results first…');
  progressBox.classList.add('show');
  progressFill.style.width='3%';
  progressCount.textContent='0 found';
  disableExtractBtns();

  try {
    await reinject(mapsTabId);
    if (!await ping(mapsTabId)) throw new Error('Could not reach Maps tab — reload it');

    const max = parseInt(maxRange.value)||60;
    setStatus('yellow','⏳ Scrolling and loading results…');
    const r = await sendToTab(mapsTabId, { action:'extractAll', max });
    const basicLeads = r?.data || [];

    if (!basicLeads.length) throw new Error('No businesses found. Search on Maps first.');

    progressFill.style.width='18%';
    setStatus('yellow',`⏳ Found ${basicLeads.length} businesses — opening background tabs for full details…`);
    progressCount.textContent=`0 / ${basicLeads.length}`;

    // FIX v4.0: timeout = 8s per lead + 30s buffer (vs Chrome's ~5min hard limit)
    const timeoutMs = basicLeads.length * 8000 + 30000;

    const result = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(
        `Timed out after ${basicLeads.length} leads. Try a smaller batch.`
      )), timeoutMs);

      chrome.runtime.sendMessage({ action:'deepExtractPhones', leads:basicLeads }, r => {
        clearTimeout(timer);
        void chrome.runtime.lastError;
        if (r?.error) reject(new Error(r.error));
        else resolve(r?.results || basicLeads);
      });
    });

    progressBox.classList.remove('show');
    enableExtractBtns();

    // FIX v4.0: save ONLY the deep results (not basic stubs first)
    // The saveLeads merge logic in background.js handles dedup
    sessionLeads = result;
    await saveLeads(result);
    await loadLeads();

    const withPhone = result.filter(l=>l.phone).length;
    const withHours = result.filter(l=>l.openingHours).length;
    const withLat   = result.filter(l=>l.lat).length;
    setStatus('green',`✅ ${result.length} leads! ${withPhone} phones, ${withHours} hours, ${withLat} coords.`);
    toast(`✅ Done! ${result.length} leads, ${withPhone} phones, ${withHours} hours.`);
    updateCounts();

  } catch(err) {
    progressBox.classList.remove('show');
    enableExtractBtns();
    setStatus('red','❌ '+err.message);
    toast(err.message, true);
  }
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg.action==='progressUpdate') {
    const n=msg.count||0, total=msg.total||parseInt(maxRange.value)||60, phase=msg.phase||'scroll';
    progressFill.style.width = Math.min(95, 18+(n/total)*77)+'%';
    if (phase==='deep') {
      progressCount.textContent=`📞 ${n} / ${total} extracted`;
      const name=msg.currentName?` — ${msg.currentName.slice(0,28)}`:''  ;
      setStatus('yellow',`⏳ Background tab extraction… (${n}/${total})${name}`);
    } else {
      progressCount.textContent=`${n} results loaded`;
    }
  }
});

function sendToTab(tabId, msg) {
  return new Promise((resolve, reject) => {
    // FIX: add timeout so this never hangs indefinitely if the Maps tab is unresponsive
    const timer = setTimeout(() => reject(new Error('Maps tab timed out — try reloading it')), 30000);
    chrome.tabs.sendMessage(tabId, msg, r => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(r);
    });
  });
}

function saveLeads(leads) {
  return new Promise(res=>{
    chrome.runtime.sendMessage({action:'saveLeads',leads},()=>{ void chrome.runtime.lastError; res(); });
  });
}

/* ── LEADS TABLE ── */
function renderTable() {
  leadsCount.textContent = allLeads.length+' leads';
  if (!allLeads.length) {
    tableWrap.innerHTML=`<div class="empty-state"><div class="icon">🗺️</div><p>No leads yet.<br/>Extract tab → extract results.</p></div>`;
    return;
  }
  tableWrap.innerHTML=`
    <table>
      <thead><tr><th>Name</th><th>Phone</th><th>City</th><th>Rating</th><th>Hours</th><th>Status</th></tr></thead>
      <tbody>${allLeads.map(l=>`
        <tr>
          <td class="td-name">${esc(l.name)}</td>
          <td class="td-phone" style="color:${l.phone?'#00c853':'#666'}">${esc(l.phone||'—')}</td>
          <td class="td-muted">${esc(l.city||l.address||'—')}</td>
          <td class="td-rating">${l.rating?'★'+l.rating:'—'}</td>
          <td class="td-muted" style="font-size:10px">${esc((l.openingHours||'').split('|')[0]||'—')}</td>
          <td style="font-size:10px;color:${l.permanentlyClosed?'#ff4757':l.temporarilyClosed?'#ffa502':'#00c853'}">${l.permanentlyClosed?'Perm. Closed':l.temporarilyClosed?'Temp. Closed':'Open'}</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
}

function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

document.getElementById('btnClear').addEventListener('click',()=>{
  if(!allLeads.length){toast('Nothing to clear',true);return;}
  if(!confirm(`Clear all ${allLeads.length} leads?`))return;
  chrome.runtime.sendMessage({action:'clearLeads'},()=>{void chrome.runtime.lastError;allLeads=[];sessionLeads=[];updateCounts();renderTable();toast('🗑️ All leads cleared');});
});

function updateCounts(){headerCount.textContent=allLeads.length;leadsCount.textContent=allLeads.length+' leads';}

/* ══════════════════════════════════════════════
   EXPORT
══════════════════════════════════════════════ */
const HEADERS = [
  'Name', 'Category', 'Phone',
  'Address', 'Street', 'Neighborhood', 'City', 'PostalCode', 'State', 'Country',
  'Website', 'Rating', 'Reviews',
  'Opening Hours', 'Permanently Closed', 'Temporarily Closed',
  'Lat', 'Lng', 'Maps URL', 'Date'
];

function leadsToRows(leads) {
  return leads.map(l => [
    l.name             || '',
    l.category         || '',
    l.phone            || '',
    l.address          || '',
    l.street           || '',
    l.neighborhood     || '',
    l.city             || '',
    l.postalCode       || '',
    l.state            || '',
    l.country          || '',
    l.website          || '',
    l.rating           || '',
    l.reviews          || '',
    l.openingHours     || '',
    l.permanentlyClosed  ? 'Yes' : 'No',
    l.temporarilyClosed  ? 'Yes' : 'No',
    l.lat              || '',
    l.lng              || '',
    l.mapsUrl          || '',
    l.date             || ''
  ]);
}

function buildExcelXML(leads) {
  const rows=leadsToRows(leads);
  const cell=v=>{const s=String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');return `<Cell><Data ss:Type="String">${s}</Data></Cell>`;};
  const hRow='<Row>'+HEADERS.map(h=>`<Cell ss:StyleID="h"><Data ss:Type="String">${h}</Data></Cell>`).join('')+'</Row>';
  const dRows=rows.map(r=>'<Row>'+r.map(cell).join('')+'</Row>').join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles><Style ss:ID="h"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1a6b35" ss:Pattern="Solid"/></Style></Styles>
<Worksheet ss:Name="GMaps Leads"><Table>${hRow}
${dRows}
</Table></Worksheet></Workbook>`;
}

function buildCSV(leads) {
  const e=v=>'"'+String(v||'').replace(/"/g,'""')+'"';
  return '\uFEFF'+[HEADERS,...leadsToRows(leads)].map(r=>r.map(e).join(',')).join('\n');
}

function dlBlob(content,name,mime){
  const url=URL.createObjectURL(new Blob([content],{type:mime}));
  chrome.downloads.download({url,filename:name},()=>setTimeout(()=>URL.revokeObjectURL(url),5000));
}
function ds(){return new Date().toISOString().split('T')[0];}

document.getElementById('btnExcelAll').addEventListener('click',()=>{if(!allLeads.length){toast('No leads!',true);return;}dlBlob(buildExcelXML(allLeads),`gmaps_leads_${ds()}.xls`,'application/vnd.ms-excel');toast(`📊 Excel — ${allLeads.length} leads`);});
document.getElementById('btnCSVAll').addEventListener('click',()=>{if(!allLeads.length){toast('No leads!',true);return;}dlBlob(buildCSV(allLeads),`gmaps_leads_${ds()}.csv`,'text/csv;charset=utf-8');toast(`📄 CSV — ${allLeads.length} leads`);});
document.getElementById('btnExcelSession').addEventListener('click',()=>{if(!sessionLeads.length){toast('Extract first!',true);return;}dlBlob(buildExcelXML(sessionLeads),`gmaps_session_${ds()}.xls`,'application/vnd.ms-excel');toast(`📊 Session Excel — ${sessionLeads.length}`);});
document.getElementById('btnCSVSession').addEventListener('click',()=>{if(!sessionLeads.length){toast('Extract first!',true);return;}dlBlob(buildCSV(sessionLeads),`gmaps_session_${ds()}.csv`,'text/csv;charset=utf-8');toast(`📄 Session CSV — ${sessionLeads.length}`);});

let _tt;
function toast(msg,isError=false){const el=document.getElementById('toast');el.textContent=msg;el.className='show'+(isError?' error':'');clearTimeout(_tt);_tt=setTimeout(()=>{el.className='';},2800);}
